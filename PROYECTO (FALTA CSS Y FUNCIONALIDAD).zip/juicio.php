<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $grado = $_POST['grado'];
    $ciencias = $_POST['ciencias'];
    $geometria = $_POST['geometria'];
    $lectura = $_POST['lectura'];
    $matematicas = $_POST['matematicas'];

    $calificaciones = [
        'ciencias' => $ciencias,
        'geometria' => $geometria,
        'lectura' => $lectura,
        'matematicas' => $matematicas
    ];

    $descripciones = [
        'excelente' => [
            'ciencias' => 'El estudiante muestra un excelente dominio en conceptos científicos y siempre participa activamente en las clases. Su curiosidad y capacidad de investigación son notables, lo que le permite entender incluso los temas más complejos.',
            'geometria' => 'El estudiante se destaca en la resolución de problemas geométricos con gran precisión y creatividad. Su habilidad para visualizar figuras geométricas y aplicar teoremas es sobresaliente.',
            'lectura' => 'El estudiante tiene una comprensión de lectura excepcional y siempre encuentra las conexiones más profundas en los textos. Su capacidad para interpretar y analizar literatura es impresionante.',
            'matematicas' => 'El estudiante sobresale en la resolución de operaciones matemáticas y siempre está dispuesto a enfrentar nuevos desafíos. Su habilidad para razonar y encontrar soluciones innovadoras es admirable.'
        ],
        'bueno' => [
            'ciencias' => 'El estudiante tiene un buen entendimiento en ciencias y participa activamente en las discusiones de clase. Aunque puede mejorar en algunas áreas, su interés y esfuerzo son evidentes.',
            'geometria' => 'El estudiante es competente en geometría y puede resolver problemas con precisión. Su comprensión de los conceptos básicos es sólida y está en camino de dominar temas más avanzados.',
            'lectura' => 'El estudiante tiene buenas habilidades de lectura y puede comprender e interpretar textos adecuadamente. Aunque hay espacio para mejorar, su progreso es constante.',
            'matematicas' => 'El estudiante tiene un buen desempeño en matemáticas y puede resolver problemas con eficacia. Con un poco más de práctica, puede alcanzar un nivel aún más alto de competencia.'
        ],
        'regular' => [
            'ciencias' => 'El estudiante tiene un rendimiento regular en ciencias y necesita enfocarse más en el estudio de los conceptos clave. Con un poco más de esfuerzo, puede mejorar significativamente.',
            'geometria' => 'El estudiante puede mejorar en geometría y debe prestar más atención a los detalles en la resolución de problemas. Su comprensión de los fundamentos es adecuada, pero requiere práctica adicional.',
            'lectura' => 'El estudiante tiene una comprensión de lectura promedio y puede beneficiarse de leer una variedad de textos para mejorar sus habilidades. Su comprensión básica está presente, pero hay margen de mejora.',
            'matematicas' => 'El estudiante tiene un rendimiento regular en matemáticas y necesita trabajar en su precisión y velocidad. Practicar más problemas puede ayudar a mejorar su confianza y habilidades.'
        ],
        'deficiente' => [
            'ciencias' => 'El estudiante necesita mejorar en ciencias y dedicar más tiempo al estudio. Su comprensión de los conceptos es limitada y se beneficiaría de una guía adicional y tutorías.',
            'geometria' => 'El estudiante tiene dificultades en geometría y necesita enfocarse en comprender los principios básicos. Asistir a clases de refuerzo puede ser útil para mejorar su desempeño.',
            'lectura' => 'El estudiante tiene problemas de comprensión de lectura y necesita practicar con diferentes tipos de textos. Un enfoque más estructurado y asistencia adicional pueden ayudarle a progresar.',
            'matematicas' => 'El estudiante necesita mejorar en matemáticas y trabajar en su comprensión de las operaciones básicas. Con la orientación adecuada y más práctica, puede lograr un mejor desempeño.'
        ],
        'pesimo' => [
            'ciencias' => 'El estudiante no se desempeña de forma correcta en ciencias y tiene dificultades para comprender los conceptos básicos. Es esencial que reciba apoyo adicional para mejorar en esta área.',
            'geometria' => 'El estudiante tiene grandes dificultades para entender geometría y requiere una atención más personalizada. Con el apoyo adecuado, puede empezar a hacer progresos significativos.',
            'lectura' => 'El estudiante presenta serias dificultades en la comprensión de textos y necesita un plan de intervención para mejorar. Leer regularmente y recibir ayuda puede marcar una gran diferencia.',
            'matematicas' => 'El estudiante no se desempeña de forma correcta al momento de realizar operaciones como multiplicaciones y divisiones. Necesita un apoyo constante y práctica para superar estas dificultades.'
        ]
    ];

    $contenido = "ID: $id\n";
    $contenido .= "Nombre: $nombre $apellido\n";
    $contenido .= "Grado: $grado\n";

    foreach ($calificaciones as $materia => $calificacion) {
        $contenido .= $descripciones[$calificacion][$materia] . "\n";
    }

    $fileName = "$nombre, $apellido.doc";
    $file = fopen($fileName, "w");
    fwrite($file, $contenido);
    fclose($file);

    header("Content-Description: File Transfer");
    header('Content-Disposition: attachment; filename="' . $fileName . '"');
    header('Content-Type: application/msword');
    readfile($fileName);
    unlink($fileName);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Formulario de Evaluación</title>
</head>
<body>
    <form method="post" action="">
        <label for="id">ID:</label><br>
        <input type="text" id="id" name="id" required><br>
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="apellido">Apellido:</label><br>
        <input type="text" id="apellido" name="apellido" required><br>
        <label for="grado">Grado:</label><br>
        <input type="text" id="grado" name="grado" required><br>

        <label for="ciencias">Calificación en Ciencias:</label><br>
        <select id="ciencias" name="ciencias" required>
            <option value="pesimo">Pésimo</option>
            <option value="deficiente">Deficiente</option>
            <option value="regular">Regular</option>
            <option value="bueno">Bueno</option>
            <option value="excelente">Excelente</option>
        </select><br>

        <label for="geometria">Calificación en Geometría:</label><br>
        <select id="geometria" name="geometria" required>
            <option value="pesimo">Pésimo</option>
            <option value="deficiente">Deficiente</option>
            <option value="regular">Regular</option>
            <option value="bueno">Bueno</option>
            <option value="excelente">Excelente</option>
        </select><br>

        <label for="lectura">Calificación en Lectura:</label><br>
        <select id="lectura" name="lectura" required>
            <option value="pesimo">Pésimo</option>
            <option value="deficiente">Deficiente</option>
            <option value="regular">Regular</option>
            <option value="bueno">Bueno</option>
            <option value="excelente">Excelente</option>
        </select><br>
        
        <label for="matematicas">Calificación en Matemáticas:</label><br>
        <select id="matematicas" name="matematicas" required>
            <option value="pesimo">Pésimo</option>
            <option value="deficiente">Deficiente</option>
            <option value="regular">Regular</option>
            <option value="bueno">Bueno</option>
            <option value="excelente">Excelente</option>
        </select><br>

        <input type="submit" value="Generar archivo">
    </form>
</body>
</html>

