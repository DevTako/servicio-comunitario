<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="barralateral.css">
    <style>
        .contenido { display: none; }
        .mostrar { display: block; }
    </style>
</head>
<body>
    <div class="barra_lateral">
        <div class="mini_barra_lateral"></div>
        <div class="nombre_pagina">
            <ion-icon id="nube" name="cloud-outline"></ion-icon>
            <span>Administrador</span>
            <script>
                document.addEventListener("DOMContentLoaded", (event) => {
                    const nube = document.getElementById("nube");
                    const barra_lateral = document.querySelector(".barra_lateral");
                    const spans = document.querySelectorAll("span");
                    nube.addEventListener("click", () => {
                        barra_lateral.classList.toggle("mini_barra_lateral");
                        spans.forEach((span) => {
                            span.classList.toggle("oculto");
                        });
                    });
                });
            </script>
        </div>
        <button class="boton">
            <ion-icon name="file-tray-full-outline"></ion-icon>
            <span>Administrar Perfiles</span>
        </button>
        <nav class="navegacion">
            <ul>
                <li>
                    <a href="#" id="ingreso_estudiantes">
                        <ion-icon name="add-circle-outline"></ion-icon>
                        <span>Ingreso de estudiantes</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <ion-icon name="reload-outline"></ion-icon>
                        <span>Actualización de datos</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <ion-icon name="swap-vertical-outline"></ion-icon>
                        <span>Migración de datos</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <ion-icon name="receipt-outline"></ion-icon>
                        <span>Creación de boletines</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <ion-icon name="print-outline"></ion-icon>
                        <span>Imprimir Boletines</span>
                    </a>
                </li>
                <li>
                    <a href="Index.html">
                        <ion-icon name="exit-outline"></ion-icon>
                        <span>Salir</span>
                    </a>
                </li>
            </ul>
        </nav>
        <div class="linea"></div>
        <div class="modo_oscuro">
            <div class="info">
                <ion-icon name="moon-outline"></ion-icon>
                <span>Modo Oscuro</span>
                <script>
                    document.addEventListener("DOMContentLoaded", (event) => {
                        const palanca = document.querySelector(".switch");
                        const circulo = document.querySelector(".circulo");
                        palanca.addEventListener("click", () => {
                            let body = document.body;
                            body.classList.toggle("dark-mode");
                            circulo.classList.toggle("prendido");
                        });
                    });
                </script>
            </div>
            <div class="switch">
                <div class="base">
                    <div class="circulo"></div>
                </div>
            </div>
        </div>
        <div class="usuario">
            <img src="/imagenes/usuario.jpg" alt="">
            <div class="info_usuario">
                <div class="usuario_email">
                    <span class="nombre">Administrador</span>
                    <span class="email">Epeevaristo@gmail.com</span>
                </div>
                <ion-icon name="ellipsis-vertical-outline"></ion-icon>
            </div>
        </div>
    </div>
    <!-- Formulario de Ingreso de Estudiantes -->
    <div class="contenido" id="formulario_estudiantes">
        <h2>Ingreso de Estudiantes</h2>
        <div class="content">
            <form action="procesar_ingreso.php" method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>
                <label for="apellido">Apellido:</label>
                <input type="text" id="apellido" name="apellido" required>
                <label for="cedula_estudiantil">Cédula Estudiantil:</label>
                <input type="text" id="cedula_estudiantil" name="cedula_estudiantil" required>
                <input type="submit" value="Registrar Estudiante">
            </form>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", (event) => {
            const ingresoEstudiantes = document.getElementById("ingreso_estudiantes");
            const formularioEstudiantes = document.getElementById("formulario_estudiantes");
            ingresoEstudiantes.addEventListener("click", (event) => {
                event.preventDefault();
                document.querySelectorAll('.contenido').forEach(el => el.classList.remove('mostrar'));
                formularioEstudiantes.classList.add('mostrar');
            });
        });
    </script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>

