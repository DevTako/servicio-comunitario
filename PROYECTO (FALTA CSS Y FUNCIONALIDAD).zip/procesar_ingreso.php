<?php
// Conexión a la base de datos
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "gestion_usuarios";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$cedula_estudiantil = $_POST['cedula_estudiantil'];

// Preparar la consulta SQL
$stmt = $conn->prepare("INSERT INTO estudiantes (nombre, apellido, cedula_estudiantil) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $apellido, $cedula_estudiantil);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Nuevo registro creado exitosamente";
} else {
    echo "Error: " . $stmt->error;
}

// Cerrar la declaración y la conexión
$stmt->close();
$conn->close();
?>
