<?php

// Crear conexión
$dsn = 'mysql:host=127.0.0.1;dbname=gestion_usuarios';
$usuario = 'root';
$contraseña = '';

try {
    $conexion = new PDO($dsn, $usuario, $contraseña);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consultar datos de la vista
    $sql = "SELECT * FROM estudiantes";
    $stmt = $conexion->query($sql);

    if ($stmt->rowCount() > 0) {
        // Mostrar datos de cada fila
        while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo $fila["cedula_estudiantil"] . ' - ' . $fila["nombre"] . ' - ' . $fila["apellido"] . '<br />';
        }
    } else {
        echo "0 resultados";
    }
} catch (PDOException $e) {
    echo "Conexión fallida: " . $e->getMessage();
}

// Cerrar conexión
$conexion = null;
?>
