<?php
session_start();

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "gestion_usuarios";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['usuario']) && isset($_POST['contrasena'])) {
        $usuario = $conn->real_escape_string($_POST['usuario']);
        $contrasena = $conn->real_escape_string($_POST['contrasena']);

        $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $_SESSION['usuario'] = $usuario;
            header("Location: barralateral.php");
            exit();
        } else {
            echo "Usuario o contraseña incorrectos.";
        }
    } else {
        echo "Por favor, complete todos los campos.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form method="post" action="">
        <label for="usuario">Usuario:</label>
        <input type="text" name="usuario" required>
        <br>
        <label for="contrasena">Contraseña:</label>
        <input type="password" name="contrasena" required>
        <br>

        <input type="submit" value="Iniciar Sesión">
    </form>
</body>
</html>
